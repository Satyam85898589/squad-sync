# SquadSync
final year project SquadSync
